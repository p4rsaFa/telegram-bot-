import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

bot = telebot.TeleBot("7901141036:AAHBcOTwD0vvWdp7ddlXv_HQk2LTjHhoWI0")

def main_menu():
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("خدمات تلگرام 🛍", callback_data="telegram_services"),
        InlineKeyboardButton("خدمات وی‌پی‌ان 🌐", callback_data="vpn_services"),
        InlineKeyboardButton("خرید شماره مجازی 📞", callback_data="virtual_number"),
        InlineKeyboardButton("کیف پول 💰", callback_data="wallet"),
        InlineKeyboardButton("پشتیبانی ☎️", callback_data="support")
    )
    return markup

@bot.message_handler(commands=["start"])
def welcome(message):
    bot.send_message(
        message.chat.id,
        "• به ربات *استارکد* خوش آمدید!\n\n"
        "• شما می‌توانید برای *خرید* یا *کنترل سرویس* خود از کیبورد پایین صفحه استفاده کنید.\n\n"
        "• در صورت وجود هرگونه سوال یا مشکل، ۲۴ ساعته با اکانت پشتیبانی در ارتباط باشید:\n"
        "@StarCodeSupport",
        reply_markup=main_menu(),
        parse_mode="Markdown"
    )

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    if call.data == "telegram_services":
        markup = InlineKeyboardMarkup(row_width=1)
        markup.add(
            InlineKeyboardButton("خرید پرمیوم تلگرام 🛍", callback_data="buy_premium"),
            InlineKeyboardButton("خرید استارز تلگرام ⭐️", callback_data="buy_stars"),
            InlineKeyboardButton("خرید بوست تلگرام 🚀", callback_data="buy_boost"),
            InlineKeyboardButton("خرید گیفت 🧸", callback_data="buy_gift"),
            InlineKeyboardButton("↩️ بازگشت به منوی اصلی", callback_data="back")
        )
        bot.edit_message_text("📦 خدمات تلگرام را انتخاب کنید:", chat_id=call.message.chat.id, message_id=call.message.message_id, reply_markup=markup)

    elif call.data == "vpn_services":
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("↩️ بازگشت به منوی اصلی", callback_data="back"))
        bot.edit_message_text(
            "❌ بخش *خدمات وی‌پی‌ان* در حال حاضر فعال نیست.\n"
            "به‌زودی با سرویس‌های حرفه‌ای باز خواهیم گشت.",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=markup,
            parse_mode="Markdown"
        )

    elif call.data == "virtual_number":
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "📞 برای خرید شماره مجازی لطفاً کشور موردنظر را انتخاب کنید...")

    elif call.data == "wallet":
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "💰 موجودی کیف پول شما: 0 تومان")

    elif call.data == "support":
        bot.answer_callback_query(call.id)
        bot.send_message(call.message.chat.id, "☎️ برای ارتباط با پشتیبانی، به آیدی زیر پیام دهید:\n@StarCodeSupport")

    elif call.data == "back":
        bot.edit_message_text(
            "• به ربات *استارکد* خوش آمدید!\n\n"
            "• شما می‌توانید برای *خرید* یا *کنترل سرویس* خود از کیبورد پایین صفحه استفاده کنید.\n\n"
            "• در صورت وجود هرگونه سوال یا مشکل، ۲۴ ساعته با اکانت پشتیبانی در ارتباط باشید:\n"
            "@StarCodeSupport",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=main_menu(),
            parse_mode="Markdown"
        )
    else:
        bot.answer_callback_query(call.id, "این بخش به‌زودی فعال خواهد شد.")

bot.polling()
